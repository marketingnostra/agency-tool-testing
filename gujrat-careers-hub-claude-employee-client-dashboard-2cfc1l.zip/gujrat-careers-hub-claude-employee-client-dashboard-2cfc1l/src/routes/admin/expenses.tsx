import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Loader2, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { AdminGuard } from "@/components/admin/AdminGuard";
import { AdminShell } from "@/components/admin/AdminShell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  EXPENSE_CATEGORIES,
  useCreateExpense,
  useDeleteExpense,
  useExpenses,
} from "@/lib/admin/expenses";

export const Route = createFileRoute("/admin/expenses")({
  component: () => (
    <AdminGuard>
      <AdminShell>
        <ExpensesPage />
      </AdminShell>
    </AdminGuard>
  ),
});

function ExpensesPage() {
  const { data: expenses, isLoading } = useExpenses();
  const [dialogOpen, setDialogOpen] = useState(false);
  const deleteExpense = useDeleteExpense();

  const totalExpenses = (expenses ?? []).reduce((sum, e) => sum + Number(e.amount), 0);

  const handleDelete = async (id: string) => {
    if (!confirm("Delete this expense?")) return;
    try {
      await deleteExpense.mutateAsync(id);
    } catch (err) {
      toast.error("Failed to delete expense", { description: (err as Error).message });
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-foreground">Office Expenses</h1>
          <p className="text-sm text-muted-foreground">
            Total spent:{" "}
            <span className="font-semibold text-destructive">
              Rs. {totalExpenses.toLocaleString()}
            </span>
          </p>
        </div>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button className="gap-2">
              <Plus className="h-4 w-4" />
              Add Expense
            </Button>
          </DialogTrigger>
          <ExpenseFormDialog onDone={() => setDialogOpen(false)} />
        </Dialog>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">All Expenses</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex justify-center py-10">
              <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
            </div>
          ) : !expenses || expenses.length === 0 ? (
            <p className="py-10 text-center text-sm text-muted-foreground">
              No expenses recorded yet.
            </p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Title</TableHead>
                  <TableHead>Category</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead className="text-right">Amount</TableHead>
                  <TableHead className="w-16" />
                </TableRow>
              </TableHeader>
              <TableBody>
                {expenses.map((expense) => (
                  <TableRow key={expense.id}>
                    <TableCell className="font-medium text-foreground">
                      {expense.title}
                      {expense.notes && (
                        <span className="block text-xs text-muted-foreground">{expense.notes}</span>
                      )}
                    </TableCell>
                    <TableCell>
                      <Badge variant="secondary">{expense.category}</Badge>
                    </TableCell>
                    <TableCell>{expense.expense_date}</TableCell>
                    <TableCell className="text-right text-destructive">
                      -Rs. {Number(expense.amount).toLocaleString()}
                    </TableCell>
                    <TableCell>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 text-destructive"
                        onClick={() => handleDelete(expense.id)}
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function ExpenseFormDialog({ onDone }: { onDone: () => void }) {
  const createExpense = useCreateExpense();
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = e.currentTarget;
    const data = new FormData(form);

    setSubmitting(true);
    try {
      await createExpense.mutateAsync({
        title: String(data.get("title")),
        category: String(data.get("category")),
        amount: Number(data.get("amount")),
        expense_date: String(data.get("expense_date")),
        notes: String(data.get("notes") || "") || null,
      });
      toast.success("Expense added");
      onDone();
    } catch (err) {
      toast.error("Failed to add expense", { description: (err as Error).message });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <DialogContent>
      <DialogHeader>
        <DialogTitle>Add Expense</DialogTitle>
      </DialogHeader>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="space-y-1.5">
          <Label htmlFor="title">Title</Label>
          <Input id="title" name="title" placeholder="Office rent – September" required />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-1.5">
            <Label htmlFor="category">Category</Label>
            <select
              id="category"
              name="category"
              defaultValue={EXPENSE_CATEGORIES[0]}
              className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm shadow-sm"
            >
              {EXPENSE_CATEGORIES.map((category) => (
                <option key={category} value={category}>
                  {category}
                </option>
              ))}
            </select>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="amount">Amount (Rs.)</Label>
            <Input id="amount" name="amount" type="number" min="0" step="1" required />
          </div>
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="expense_date">Date</Label>
          <Input
            id="expense_date"
            name="expense_date"
            type="date"
            defaultValue={new Date().toISOString().slice(0, 10)}
            required
          />
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="notes">Notes (optional)</Label>
          <Textarea id="notes" name="notes" rows={2} />
        </div>
        <Button type="submit" className="w-full" disabled={submitting}>
          {submitting && <Loader2 className="h-4 w-4 animate-spin" />}
          Add expense
        </Button>
      </form>
    </DialogContent>
  );
}
