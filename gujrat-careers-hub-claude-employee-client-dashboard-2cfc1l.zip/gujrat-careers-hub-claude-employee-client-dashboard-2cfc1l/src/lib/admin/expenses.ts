import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { Tables, TablesInsert } from "@/integrations/supabase/types";

export type OfficeExpense = Tables<"office_expenses">;
export type OfficeExpenseInsert = TablesInsert<"office_expenses">;

export const EXPENSE_CATEGORIES = [
  "Rent",
  "Utilities",
  "Salaries",
  "Software & Tools",
  "Marketing",
  "Equipment",
  "General",
] as const;

const EXPENSES_KEY = ["admin", "expenses"] as const;

export function useExpenses() {
  return useQuery({
    queryKey: EXPENSES_KEY,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("office_expenses")
        .select("*")
        .order("expense_date", { ascending: false });
      if (error) throw error;
      return data as OfficeExpense[];
    },
  });
}

export function useCreateExpense() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (input: OfficeExpenseInsert) => {
      const { data, error } = await supabase
        .from("office_expenses")
        .insert(input)
        .select()
        .single();
      if (error) throw error;
      return data as OfficeExpense;
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: EXPENSES_KEY }),
  });
}

export function useDeleteExpense() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("office_expenses").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: EXPENSES_KEY }),
  });
}
