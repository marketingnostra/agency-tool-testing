import { createFileRoute } from "@tanstack/react-router";
import { Bar, BarChart, CartesianGrid, Cell, Pie, PieChart, XAxis } from "recharts";
import { Banknote, Loader2, PiggyBank, TrendingDown, TrendingUp } from "lucide-react";
import { AdminGuard } from "@/components/admin/AdminGuard";
import { AdminShell } from "@/components/admin/AdminShell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
  type ChartConfig,
} from "@/components/ui/chart";
import { useFinanceSummary } from "@/lib/admin/finance";

export const Route = createFileRoute("/admin/")({
  component: () => (
    <AdminGuard>
      <AdminShell>
        <OverviewPage />
      </AdminShell>
    </AdminGuard>
  ),
});

const trendConfig: ChartConfig = {
  income: { label: "Income", color: "oklch(0.62 0.15 145)" },
  expenses: { label: "Expenses", color: "var(--destructive)" },
  investments: { label: "Investments", color: "var(--primary)" },
};

const EXPENSE_COLORS = [
  "var(--primary)",
  "oklch(0.62 0.15 145)",
  "var(--destructive)",
  "oklch(0.75 0.15 70)",
  "oklch(0.6 0.15 300)",
  "oklch(0.65 0.1 220)",
  "var(--muted-foreground)",
];

function OverviewPage() {
  const summary = useFinanceSummary();

  if (summary.isLoading) {
    return (
      <div className="flex justify-center py-20">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  const expenseConfig: ChartConfig = Object.fromEntries(
    summary.expenseBreakdown.map((item, i) => [
      item.category,
      { label: item.category, color: EXPENSE_COLORS[i % EXPENSE_COLORS.length] },
    ]),
  );

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold text-foreground">Finance Overview</h1>
        <p className="text-sm text-muted-foreground">Live snapshot of the business's finances.</p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <SummaryCard
          label="Account Balance"
          value={summary.balance}
          icon={PiggyBank}
          tone={summary.balance >= 0 ? "positive" : "negative"}
        />
        <SummaryCard
          label="Income Received"
          value={summary.totalIncome}
          icon={TrendingUp}
          tone="positive"
        />
        <SummaryCard
          label="Office Expenses"
          value={summary.totalExpenses}
          icon={TrendingDown}
          tone="negative"
        />
        <SummaryCard
          label="Pending Payments"
          value={summary.totalPending}
          icon={Banknote}
          tone="neutral"
          hint={`${summary.pendingCount} invoice${summary.pendingCount === 1 ? "" : "s"} outstanding`}
        />
      </div>

      <div className="grid gap-4 lg:grid-cols-5">
        <Card className="lg:col-span-3">
          <CardHeader>
            <CardTitle className="text-base">Income vs Expenses vs Investments</CardTitle>
          </CardHeader>
          <CardContent>
            {summary.monthlySeries.length === 0 ? (
              <p className="py-16 text-center text-sm text-muted-foreground">
                No financial activity recorded yet.
              </p>
            ) : (
              <ChartContainer config={trendConfig} className="h-72 w-full">
                <BarChart data={summary.monthlySeries}>
                  <CartesianGrid vertical={false} />
                  <XAxis dataKey="month" tickLine={false} axisLine={false} tickMargin={8} />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Bar dataKey="income" fill="var(--color-income)" radius={4} />
                  <Bar dataKey="expenses" fill="var(--color-expenses)" radius={4} />
                  <Bar dataKey="investments" fill="var(--color-investments)" radius={4} />
                </BarChart>
              </ChartContainer>
            )}
          </CardContent>
        </Card>

        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-base">Expense Breakdown</CardTitle>
          </CardHeader>
          <CardContent>
            {summary.expenseBreakdown.length === 0 ? (
              <p className="py-16 text-center text-sm text-muted-foreground">
                No expenses recorded yet.
              </p>
            ) : (
              <ChartContainer config={expenseConfig} className="mx-auto aspect-square max-h-72">
                <PieChart>
                  <ChartTooltip content={<ChartTooltipContent hideLabel />} />
                  <Pie
                    data={summary.expenseBreakdown}
                    dataKey="amount"
                    nameKey="category"
                    innerRadius={50}
                  >
                    {summary.expenseBreakdown.map((entry, i) => (
                      <Cell key={entry.category} fill={EXPENSE_COLORS[i % EXPENSE_COLORS.length]} />
                    ))}
                  </Pie>
                </PieChart>
              </ChartContainer>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function SummaryCard({
  label,
  value,
  icon: Icon,
  tone,
  hint,
}: {
  label: string;
  value: number;
  icon: React.ComponentType<{ className?: string }>;
  tone: "positive" | "negative" | "neutral";
  hint?: string;
}) {
  const toneClass =
    tone === "positive"
      ? "text-emerald-600"
      : tone === "negative"
        ? "text-destructive"
        : "text-foreground";

  return (
    <Card>
      <CardContent className="flex items-start justify-between p-5">
        <div>
          <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
            {label}
          </p>
          <p className={`mt-1 text-2xl font-semibold ${toneClass}`}>Rs. {value.toLocaleString()}</p>
          {hint && <p className="mt-1 text-xs text-muted-foreground">{hint}</p>}
        </div>
        <div className="rounded-full bg-accent p-2 text-accent-foreground">
          <Icon className="h-4 w-4" />
        </div>
      </CardContent>
    </Card>
  );
}
