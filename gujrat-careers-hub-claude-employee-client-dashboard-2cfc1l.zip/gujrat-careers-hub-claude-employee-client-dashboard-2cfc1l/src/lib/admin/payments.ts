import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { Tables, TablesInsert, TablesUpdate } from "@/integrations/supabase/types";

export type ClientPayment = Tables<"client_payments">;
export type ClientPaymentInsert = TablesInsert<"client_payments">;
export type ClientPaymentUpdate = TablesUpdate<"client_payments">;

export type ClientPaymentWithClient = ClientPayment & {
  client: Pick<Tables<"clients">, "id" | "client_name" | "business_name"> | null;
};

const PAYMENTS_KEY = ["admin", "payments"] as const;

export function usePayments() {
  return useQuery({
    queryKey: PAYMENTS_KEY,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("client_payments")
        .select("*, client:clients(id, client_name, business_name)")
        .order("period_month", { ascending: false });
      if (error) throw error;
      return data as unknown as ClientPaymentWithClient[];
    },
  });
}

export function useCreatePayment() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (input: ClientPaymentInsert) => {
      const { data, error } = await supabase
        .from("client_payments")
        .insert(input)
        .select()
        .single();
      if (error) throw error;
      return data as ClientPayment;
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: PAYMENTS_KEY }),
  });
}

export function useUpdatePaymentStatus() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, status }: { id: string; status: "pending" | "cleared" }) => {
      const { data, error } = await supabase
        .from("client_payments")
        .update({
          status,
          paid_date: status === "cleared" ? new Date().toISOString().slice(0, 10) : null,
        })
        .eq("id", id)
        .select()
        .single();
      if (error) throw error;
      return data as ClientPayment;
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: PAYMENTS_KEY }),
  });
}

export function useDeletePayment() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("client_payments").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: PAYMENTS_KEY }),
  });
}
