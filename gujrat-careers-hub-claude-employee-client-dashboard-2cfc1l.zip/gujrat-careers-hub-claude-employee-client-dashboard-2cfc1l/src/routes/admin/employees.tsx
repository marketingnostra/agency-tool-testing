import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Loader2, Pencil, Plus, Trash2, User } from "lucide-react";
import { toast } from "sonner";
import { AdminGuard } from "@/components/admin/AdminGuard";
import { AdminShell } from "@/components/admin/AdminShell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  type Employee,
  uploadEmployeePhoto,
  useCreateEmployee,
  useDeleteEmployee,
  useEmployees,
  useUpdateEmployee,
} from "@/lib/admin/employees";

export const Route = createFileRoute("/admin/employees")({
  component: () => (
    <AdminGuard>
      <AdminShell>
        <EmployeesPage />
      </AdminShell>
    </AdminGuard>
  ),
});

function EmployeesPage() {
  const { data: employees, isLoading } = useEmployees();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<Employee | null>(null);

  const openCreate = () => {
    setEditing(null);
    setDialogOpen(true);
  };

  const openEdit = (employee: Employee) => {
    setEditing(employee);
    setDialogOpen(true);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-foreground">Employees</h1>
          <p className="text-sm text-muted-foreground">Manage your team's records and salaries.</p>
        </div>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={openCreate} className="gap-2">
              <Plus className="h-4 w-4" />
              Add Employee
            </Button>
          </DialogTrigger>
          <EmployeeFormDialog
            key={editing?.id ?? "new"}
            employee={editing}
            onDone={() => setDialogOpen(false)}
          />
        </Dialog>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">All Employees</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex justify-center py-10">
              <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
            </div>
          ) : !employees || employees.length === 0 ? (
            <p className="py-10 text-center text-sm text-muted-foreground">No employees yet.</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Employee</TableHead>
                  <TableHead>ID</TableHead>
                  <TableHead>CNIC</TableHead>
                  <TableHead>Designation</TableHead>
                  <TableHead className="text-right">Salary</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="w-20" />
                </TableRow>
              </TableHeader>
              <TableBody>
                {employees.map((employee) => (
                  <EmployeeRow
                    key={employee.id}
                    employee={employee}
                    onEdit={() => openEdit(employee)}
                  />
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function EmployeeRow({ employee, onEdit }: { employee: Employee; onEdit: () => void }) {
  const deleteEmployee = useDeleteEmployee();

  const handleDelete = async () => {
    if (!confirm(`Remove ${employee.full_name} from employees?`)) return;
    try {
      await deleteEmployee.mutateAsync(employee.id);
      toast.success("Employee removed");
    } catch (err) {
      toast.error("Failed to remove employee", { description: (err as Error).message });
    }
  };

  return (
    <TableRow>
      <TableCell>
        <div className="flex items-center gap-3">
          <Avatar className="h-8 w-8">
            <AvatarImage src={employee.photo_url ?? undefined} alt={employee.full_name} />
            <AvatarFallback>
              <User className="h-4 w-4" />
            </AvatarFallback>
          </Avatar>
          <span className="font-medium text-foreground">{employee.full_name}</span>
        </div>
      </TableCell>
      <TableCell className="font-mono text-xs">{employee.employee_code}</TableCell>
      <TableCell className="font-mono text-xs">{employee.cnic}</TableCell>
      <TableCell>{employee.designation}</TableCell>
      <TableCell className="text-right">Rs. {Number(employee.salary).toLocaleString()}</TableCell>
      <TableCell>
        <Badge variant={employee.status === "active" ? "default" : "secondary"}>
          {employee.status}
        </Badge>
      </TableCell>
      <TableCell>
        <div className="flex justify-end gap-1">
          <Button variant="ghost" size="icon" className="h-8 w-8" onClick={onEdit}>
            <Pencil className="h-3.5 w-3.5" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8 text-destructive"
            onClick={handleDelete}
            disabled={deleteEmployee.isPending}
          >
            <Trash2 className="h-3.5 w-3.5" />
          </Button>
        </div>
      </TableCell>
    </TableRow>
  );
}

function EmployeeFormDialog({
  employee,
  onDone,
}: {
  employee: Employee | null;
  onDone: () => void;
}) {
  const createEmployee = useCreateEmployee();
  const updateEmployee = useUpdateEmployee();
  const [photoFile, setPhotoFile] = useState<File | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const isEditing = !!employee;

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = e.currentTarget;
    const data = new FormData(form);
    const employeeCode = String(data.get("employee_code"));

    setSubmitting(true);
    try {
      let photoUrl = employee?.photo_url ?? null;
      if (photoFile) {
        photoUrl = await uploadEmployeePhoto(photoFile, employeeCode);
      }

      const payload = {
        employee_code: employeeCode,
        full_name: String(data.get("full_name")),
        cnic: String(data.get("cnic")),
        designation: String(data.get("designation")),
        salary: Number(data.get("salary")),
        status: String(data.get("status")) as "active" | "inactive",
        photo_url: photoUrl,
      };

      if (isEditing) {
        await updateEmployee.mutateAsync({ id: employee.id, ...payload });
        toast.success("Employee updated");
      } else {
        await createEmployee.mutateAsync(payload);
        toast.success("Employee added");
      }
      setPhotoFile(null);
      onDone();
    } catch (err) {
      toast.error("Failed to save employee", { description: (err as Error).message });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <DialogContent>
      <DialogHeader>
        <DialogTitle>{isEditing ? "Edit Employee" : "Add Employee"}</DialogTitle>
      </DialogHeader>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-1.5">
            <Label htmlFor="full_name">Full name</Label>
            <Input id="full_name" name="full_name" defaultValue={employee?.full_name} required />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="employee_code">Employee ID</Label>
            <Input
              id="employee_code"
              name="employee_code"
              placeholder="EMP-001"
              defaultValue={employee?.employee_code}
              required
            />
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-1.5">
            <Label htmlFor="cnic">CNIC number</Label>
            <Input
              id="cnic"
              name="cnic"
              placeholder="XXXXX-XXXXXXX-X"
              defaultValue={employee?.cnic}
              required
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="designation">Designation</Label>
            <Input
              id="designation"
              name="designation"
              defaultValue={employee?.designation}
              required
            />
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-1.5">
            <Label htmlFor="salary">Salary (Rs.)</Label>
            <Input
              id="salary"
              name="salary"
              type="number"
              min="0"
              step="1"
              defaultValue={employee?.salary}
              required
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="status">Status</Label>
            <select
              id="status"
              name="status"
              defaultValue={employee?.status ?? "active"}
              className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm shadow-sm"
            >
              <option value="active">Active</option>
              <option value="inactive">Inactive</option>
            </select>
          </div>
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="photo">Picture</Label>
          <Input
            id="photo"
            name="photo"
            type="file"
            accept="image/*"
            onChange={(e) => setPhotoFile(e.target.files?.[0] ?? null)}
          />
        </div>
        <Button type="submit" className="w-full" disabled={submitting}>
          {submitting && <Loader2 className="h-4 w-4 animate-spin" />}
          {isEditing ? "Save changes" : "Add employee"}
        </Button>
      </form>
    </DialogContent>
  );
}
