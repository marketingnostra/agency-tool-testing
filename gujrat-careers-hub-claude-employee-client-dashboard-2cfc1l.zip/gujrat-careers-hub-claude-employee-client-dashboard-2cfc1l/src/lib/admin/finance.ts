import { useMemo } from "react";
import { usePayments } from "@/lib/admin/payments";
import { useExpenses } from "@/lib/admin/expenses";
import { useInvestments } from "@/lib/admin/investments";

function monthKey(dateStr: string) {
  return dateStr.slice(0, 7); // YYYY-MM
}

function monthLabel(key: string) {
  const [year, month] = key.split("-").map(Number);
  return new Date(year, month - 1, 1).toLocaleDateString("en-US", {
    month: "short",
    year: "2-digit",
  });
}

export function useFinanceSummary() {
  const paymentsQuery = usePayments();
  const expensesQuery = useExpenses();
  const investmentsQuery = useInvestments();

  const isLoading =
    paymentsQuery.isLoading || expensesQuery.isLoading || investmentsQuery.isLoading;

  const summary = useMemo(() => {
    const payments = paymentsQuery.data ?? [];
    const expenses = expensesQuery.data ?? [];
    const investments = investmentsQuery.data ?? [];

    const clearedPayments = payments.filter((p) => p.status === "cleared");
    const pendingPayments = payments.filter((p) => p.status === "pending");

    const totalIncome = clearedPayments.reduce((sum, p) => sum + Number(p.amount), 0);
    const totalPending = pendingPayments.reduce((sum, p) => sum + Number(p.amount), 0);
    const totalExpenses = expenses.reduce((sum, e) => sum + Number(e.amount), 0);
    const totalInvestments = investments.reduce((sum, i) => sum + Number(i.amount), 0);
    const balance = totalInvestments + totalIncome - totalExpenses;

    const monthly = new Map<string, { income: number; expenses: number; investments: number }>();
    const ensure = (key: string) => {
      if (!monthly.has(key)) monthly.set(key, { income: 0, expenses: 0, investments: 0 });
      return monthly.get(key)!;
    };

    clearedPayments.forEach((p) => {
      const key = monthKey(p.paid_date ?? p.period_month);
      ensure(key).income += Number(p.amount);
    });
    expenses.forEach((e) => {
      ensure(monthKey(e.expense_date)).expenses += Number(e.amount);
    });
    investments.forEach((i) => {
      ensure(monthKey(i.invested_date)).investments += Number(i.amount);
    });

    const monthlySeries = Array.from(monthly.entries())
      .sort(([a], [b]) => a.localeCompare(b))
      .slice(-6)
      .map(([key, value]) => ({ month: monthLabel(key), ...value }));

    const expenseByCategory = new Map<string, number>();
    expenses.forEach((e) => {
      expenseByCategory.set(
        e.category,
        (expenseByCategory.get(e.category) ?? 0) + Number(e.amount),
      );
    });
    const expenseBreakdown = Array.from(expenseByCategory.entries()).map(([category, amount]) => ({
      category,
      amount,
    }));

    return {
      totalIncome,
      totalPending,
      pendingCount: pendingPayments.length,
      totalExpenses,
      totalInvestments,
      balance,
      monthlySeries,
      expenseBreakdown,
    };
  }, [paymentsQuery.data, expensesQuery.data, investmentsQuery.data]);

  return { ...summary, isLoading };
}
