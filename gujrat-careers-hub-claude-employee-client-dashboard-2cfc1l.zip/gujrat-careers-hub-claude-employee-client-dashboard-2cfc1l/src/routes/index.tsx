import { createFileRoute } from "@tanstack/react-router";
import { Toaster } from "@/components/ui/sonner";
import { Button } from "@/components/ui/button";
import { ApplicationForm } from "@/components/ApplicationForm";
import heroImg from "@/assets/hero-marketing.jpg";
import {
  Sparkles,
  GraduationCap,
  Briefcase,
  MapPin,
  Mail,
  Phone,
  Linkedin,
  Globe,
  CheckCircle2,
  Megaphone,
  PenTool,
  Video,
  Rocket,
  Award,
  Users,
  Zap,
} from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Careers at Marketing Nostra – Hiring Interns & Experts in Gujrat" },
      { name: "description", content: "Join Marketing Nostra Pvt Ltd. 3-month paid-track internship and expert roles in Social Media, Graphic Design and Video Editing at our Gujrat office." },
      { property: "og:title", content: "Careers at Marketing Nostra – Hiring Interns & Experts in Gujrat" },
      { property: "og:description", content: "Internships and full-time roles in digital marketing at our Gujrat, Punjab office." },
    ],
  }),
  component: HiringPage,
});

function HiringPage() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <Toaster richColors position="top-center" />
      <Header />
      <Hero />
      <About />
      <Internship />
      <Jobs />
      <Location />
      <Contact />
      <Footer />
    </div>
  );
}

/* ---------------- HEADER ---------------- */
function Header() {
  return (
    <header className="sticky top-0 z-40 w-full border-b border-border/60 bg-background/80 backdrop-blur">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 sm:px-6 py-3">
        <a href="#top" className="flex items-center gap-2">
          <span className="inline-flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-hero text-primary-foreground shadow-glow">
            <Sparkles className="h-4 w-4" />
          </span>
          <div className="leading-tight">
            <p className="font-display text-sm font-bold">Marketing Nostra</p>
            <p className="text-[10px] uppercase tracking-widest text-muted-foreground">Careers</p>
          </div>
        </a>
        <nav className="hidden md:flex items-center gap-7 text-sm font-medium">
          <a href="#about" className="text-muted-foreground hover:text-foreground transition">About</a>
          <a href="#internship" className="text-muted-foreground hover:text-foreground transition">Internship</a>
          <a href="#jobs" className="text-muted-foreground hover:text-foreground transition">Jobs</a>
          <a href="#contact" className="text-muted-foreground hover:text-foreground transition">Contact</a>
        </nav>
        <Button asChild variant="hero" size="sm">
          <a href="#apply">Apply Now</a>
        </Button>
      </div>
    </header>
  );
}

/* ---------------- HERO ---------------- */
function Hero() {
  return (
    <section id="top" className="relative overflow-hidden">
      <div
        aria-hidden
        className="pointer-events-none absolute -top-40 -right-40 h-[520px] w-[520px] rounded-full bg-gradient-hero opacity-20 blur-3xl"
      />
      <div
        aria-hidden
        className="pointer-events-none absolute -bottom-40 -left-40 h-[420px] w-[420px] rounded-full bg-gradient-accent opacity-20 blur-3xl"
      />
      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 pt-14 pb-20 lg:pt-20 lg:pb-28">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          <div className="animate-fade-up">
            <span className="inline-flex items-center gap-2 rounded-full border border-border bg-secondary/60 px-3 py-1 text-xs font-medium text-secondary-foreground">
              <span className="h-1.5 w-1.5 rounded-full bg-primary animate-pulse" />
              Now hiring · Gujrat, Punjab
            </span>
            <h1 className="mt-5 font-display text-4xl sm:text-5xl lg:text-6xl font-bold leading-[1.05]">
              Join Marketing Nostra —{" "}
              <span className="text-gradient">We're hiring Interns & Experts</span>{" "}
              at our Gujrat Office.
            </h1>
            <p className="mt-5 text-base sm:text-lg text-muted-foreground max-w-xl">
              We're Pakistan's leading digital marketing agency
              building winning campaigns for aesthetics clinics, F&B brands and SaaS companies.
              Build your career with a team that ships fast and grows together.
            </p>
            <div className="mt-7 flex flex-wrap gap-3">
              <Button asChild variant="hero" size="lg">
                <a href="#apply">Apply Now</a>
              </Button>
              <Button asChild variant="outline" size="lg">
                <a href="#about">Learn about us</a>
              </Button>
            </div>
            <div className="mt-10 grid grid-cols-3 gap-4 max-w-md">
              {[
                { k: "8+", v: "Years experience" },
                { k: "3-mo", v: "Internship" },
                { k: "1", v: "Office hiring" },
              ].map((s) => (
                <div key={s.v} className="rounded-xl border border-border/70 bg-card/60 p-3 text-center shadow-card-soft">
                  <p className="font-display text-xl font-bold text-gradient">{s.k}</p>
                  <p className="text-[11px] text-muted-foreground">{s.v}</p>
                </div>
              ))}
            </div>
          </div>

          <div id="apply" className="relative animate-fade-up" style={{ animationDelay: "120ms" }}>
            <div
              aria-hidden
              className="absolute -inset-4 rounded-3xl bg-gradient-hero opacity-20 blur-2xl"
            />
            <div className="relative">
              <img
                src={heroImg}
                alt=""
                width={1280}
                height={1024}
                className="absolute -top-10 -right-10 hidden lg:block h-24 w-24 rounded-2xl object-cover opacity-70 animate-float"
              />
              <ApplicationForm />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ---------------- ABOUT ---------------- */
function About() {
  const points = [
    { icon: Megaphone, title: "Performance & automation", text: "Meta/Facebook Ads, WhatsApp Business API, social commerce, lead gen & automation." },
    { icon: Users, title: "Diverse client base", text: "We work with aesthetics clinics, food & beverage outlets and SaaS companies." },
    { icon: Zap, title: "AI & no-code first", text: "We build with Lovable, n8n and modern AI tools for rapid product development." },
    { icon: Award, title: "Founder-led culture", text: "Founded by experienced digital marketers building multiple business ventures." },
  ];

  return (
    <section id="about" className="bg-gradient-soft py-20 sm:py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="mx-auto max-w-2xl text-center">
          <p className="text-xs font-semibold uppercase tracking-[0.2em] text-primary">About us</p>
          <h2 className="mt-3 font-display text-3xl sm:text-4xl font-bold">
            Where ambitious marketers grow.
          </h2>
          <p className="mt-4 text-muted-foreground">
            We blend deep marketing craft with modern automation to ship campaigns that move the needle.
          </p>
        </div>

        <div className="mt-12 grid md:grid-cols-2 lg:grid-cols-3 gap-5">
          {points.map(({ icon: Icon, title, text }) => (
            <div key={title} className="group rounded-2xl border border-border bg-card p-6 shadow-card-soft transition hover:-translate-y-1 hover:shadow-elegant">
              <div className="inline-flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-accent text-primary-foreground">
                <Icon className="h-5 w-5" />
              </div>
              <h3 className="mt-4 font-display text-lg font-semibold">{title}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{text}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------------- INTERNSHIP ---------------- */
const SKILLS = [
  { icon: Megaphone, name: "Social Media Management", text: "Run content calendars, ads and project management for real brands." },
  { icon: PenTool, name: "Graphic Design", text: "Design scroll-stopping creatives across formats and channels." },
  { icon: Video, name: "Video Editing", text: "Edit short-form and brand videos that perform on every platform." },
];

function Internship() {
  const features = [
    "3-month structured program",
    "Proper guidance & hands-on training",
    "Certificate upon completion",
    "Job offer for top performers",
    "No prior experience required — passion for learning is essential",
    "On-site at Gujrat office only",
  ];
  return (
    <section id="internship" className="py-20 sm:py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="grid lg:grid-cols-2 gap-12 items-start">
          <div>
            <span className="inline-flex items-center gap-2 rounded-full border border-border bg-secondary/60 px-3 py-1 text-xs font-medium">
              <GraduationCap className="h-3.5 w-3.5 text-primary" />
              Internship Program
            </span>
            <h2 className="mt-4 font-display text-3xl sm:text-4xl font-bold leading-tight">
              Launch your career with a <span className="text-gradient">3-month structured</span> internship.
            </h2>
            <p className="mt-4 text-muted-foreground">
              Get mentored by working professionals, build real campaigns, and earn a certificate.
              Top performers receive a direct job offer at Marketing Nostra.
            </p>
            <ul className="mt-6 space-y-3">
              {features.map((f) => (
                <li key={f} className="flex items-start gap-3 text-sm">
                  <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-primary" />
                  <span>{f}</span>
                </li>
              ))}
            </ul>
            <div className="mt-7">
              <Button asChild variant="hero" size="lg">
                <a href="#apply">Apply for internship</a>
              </Button>
            </div>
          </div>

          <div className="grid gap-4">
            {SKILLS.map(({ icon: Icon, name, text }) => (
              <div key={name} className="flex gap-4 rounded-2xl border border-border bg-card p-5 shadow-card-soft">
                <div className="inline-flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-gradient-hero text-primary-foreground">
                  <Icon className="h-5 w-5" />
                </div>
                <div>
                  <h3 className="font-display text-base font-semibold">{name}</h3>
                  <p className="mt-1 text-sm text-muted-foreground">{text}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

/* ---------------- JOBS ---------------- */
function Jobs() {
  const points = [
    "Proven experts with hands-on experience",
    "Honest, dedicated and skilled professionals",
    "Competitive salary based on experience",
    "Full-time, on-site at Gujrat office",
  ];
  return (
    <section id="jobs" className="py-20 sm:py-24 bg-gradient-soft">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="mx-auto max-w-2xl text-center">
          <span className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-3 py-1 text-xs font-medium">
            <Briefcase className="h-3.5 w-3.5 text-primary" />
            Job Opportunities
          </span>
          <h2 className="mt-4 font-display text-3xl sm:text-4xl font-bold">
            Bring your expertise. <span className="text-gradient">Grow with us.</span>
          </h2>
          <p className="mt-4 text-muted-foreground">
            We're hiring proven experts who care about craft, communication and consistent results.
          </p>
        </div>

        <div className="mt-12 grid md:grid-cols-3 gap-5">
          {SKILLS.map(({ icon: Icon, name }) => (
            <div key={name} className="group relative overflow-hidden rounded-2xl border border-border bg-card p-6 shadow-card-soft transition hover:-translate-y-1 hover:shadow-elegant">
              <div className="inline-flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-accent text-primary-foreground">
                <Icon className="h-5 w-5" />
              </div>
              <h3 className="mt-4 font-display text-lg font-semibold">{name}</h3>
              <p className="mt-2 text-sm text-muted-foreground">Full-time · On-site · Gujrat</p>
              <div className="mt-5">
                <Button asChild variant="soft" size="sm">
                  <a href="#apply">Apply for this role</a>
                </Button>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-12 mx-auto max-w-3xl rounded-2xl border border-border bg-card p-6 shadow-card-soft">
          <h3 className="font-display text-lg font-semibold">What we look for</h3>
          <ul className="mt-4 grid sm:grid-cols-2 gap-3">
            {points.map((p) => (
              <li key={p} className="flex items-start gap-3 text-sm">
                <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-primary" />
                <span>{p}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  );
}

/* ---------------- LOCATION ---------------- */
function Location() {
  return (
    <section className="py-20 sm:py-24">
      <div className="mx-auto max-w-5xl px-4 sm:px-6">
        <div className="relative overflow-hidden rounded-3xl bg-gradient-hero p-8 sm:p-12 text-primary-foreground shadow-elegant">
          <div aria-hidden className="absolute -top-20 -right-20 h-64 w-64 rounded-full bg-white/10 blur-2xl" />
          <div aria-hidden className="absolute -bottom-20 -left-20 h-64 w-64 rounded-full bg-white/10 blur-2xl" />
          <div className="relative grid md:grid-cols-[auto_1fr] gap-6 items-center">
            <div className="inline-flex h-20 w-20 items-center justify-center rounded-2xl bg-white/15 backdrop-blur">
              <MapPin className="h-9 w-9" />
            </div>
            <div>
              <p className="text-xs font-semibold uppercase tracking-[0.2em] opacity-80">Hiring Location</p>
              <h2 className="mt-2 font-display text-2xl sm:text-3xl font-bold">
                Gujrat Office — Punjab, Pakistan
              </h2>
              <p className="mt-2 text-sm sm:text-base opacity-90">
                We are currently hiring for our Gujrat office only. All roles are on-site.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ---------------- CONTACT ---------------- */
function Contact() {
  const items = [
    { icon: Mail, label: "Email", value: "hr@marketingnostra.com", href: "mailto:hr@marketingnostra.com" },
    { icon: Phone, label: "WhatsApp", value: "+92 326 8792593", href: "https://wa.me/923268792593" },
    { icon: Linkedin, label: "LinkedIn", value: "Marketing Nostra", href: "https://www.linkedin.com/company/marketing-nostra/" },
    { icon: Globe, label: "Website", value: "www.marketingnostra.com", href: "https://www.marketingnostra.com" },
    { icon: MapPin, label: "Address", value: "Gujrat, Punjab, PK", href: "#" },
  ];
  return (
    <section id="contact" className="py-20 sm:py-24 bg-gradient-soft">
      <div className="mx-auto max-w-5xl px-4 sm:px-6">
        <div className="text-center">
          <p className="text-xs font-semibold uppercase tracking-[0.2em] text-primary">Get in touch</p>
          <h2 className="mt-3 font-display text-3xl sm:text-4xl font-bold">Contact our HR team</h2>
          <p className="mt-3 text-muted-foreground max-w-xl mx-auto">
            Questions before applying? Reach out — we usually respond within one business day.
          </p>
        </div>
        <div className="mt-10 grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {items.map(({ icon: Icon, label, value, href }) => (
            <a
              key={label}
              href={href}
              target={href.startsWith("http") ? "_blank" : undefined}
              rel="noreferrer"
              className="group flex items-start gap-4 rounded-2xl border border-border bg-card p-5 shadow-card-soft transition hover:-translate-y-1 hover:shadow-elegant"
            >
              <div className="inline-flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-gradient-accent text-primary-foreground">
                <Icon className="h-5 w-5" />
              </div>
              <div>
                <p className="text-xs uppercase tracking-widest text-muted-foreground">{label}</p>
                <p className="mt-0.5 font-medium group-hover:text-primary transition">{value}</p>
              </div>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------------- FOOTER ---------------- */
function Footer() {
  return (
    <footer className="border-t border-border bg-background">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 py-10 grid gap-6 md:grid-cols-2 items-center">
        <div className="flex items-center gap-2">
          <span className="inline-flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-hero text-primary-foreground">
            <Sparkles className="h-4 w-4" />
          </span>
          <div>
            <p className="font-display text-sm font-bold">Marketing Nostra Pvt Ltd</p>
            <p className="text-xs text-muted-foreground">Gujrat, Punjab, Pakistan</p>
          </div>
        </div>
        <div className="flex flex-wrap md:justify-end items-center gap-4 text-sm">
          <a href="https://www.linkedin.com/company/marketing-nostra/" target="_blank" rel="noreferrer" className="text-muted-foreground hover:text-foreground inline-flex items-center gap-1.5">
            <Linkedin className="h-4 w-4" /> LinkedIn
          </a>
          <a href="https://www.marketingnostra.com" target="_blank" rel="noreferrer" className="text-muted-foreground hover:text-foreground inline-flex items-center gap-1.5">
            <Globe className="h-4 w-4" /> Website
          </a>
          <a href="mailto:hr@marketingnostra.com" className="text-muted-foreground hover:text-foreground inline-flex items-center gap-1.5">
            <Mail className="h-4 w-4" /> hr@marketingnostra.com
          </a>
        </div>
      </div>
      <div className="border-t border-border py-5 text-center text-xs text-muted-foreground">
        © {new Date().getFullYear()} Marketing Nostra Pvt Ltd. All rights reserved.
      </div>
    </footer>
  );
}
