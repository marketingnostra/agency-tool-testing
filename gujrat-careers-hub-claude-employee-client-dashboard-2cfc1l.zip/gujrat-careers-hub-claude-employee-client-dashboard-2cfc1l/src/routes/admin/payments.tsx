import { useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { CheckCircle2, Clock, Loader2, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { AdminGuard } from "@/components/admin/AdminGuard";
import { AdminShell } from "@/components/admin/AdminShell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useClients } from "@/lib/admin/clients";
import {
  useCreatePayment,
  useDeletePayment,
  usePayments,
  useUpdatePaymentStatus,
} from "@/lib/admin/payments";

export const Route = createFileRoute("/admin/payments")({
  component: () => (
    <AdminGuard>
      <AdminShell>
        <PaymentsPage />
      </AdminShell>
    </AdminGuard>
  ),
});

function PaymentsPage() {
  const { data: payments, isLoading } = usePayments();
  const [dialogOpen, setDialogOpen] = useState(false);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-foreground">Payments</h1>
          <p className="text-sm text-muted-foreground">
            Track monthly retainer payments per client.
          </p>
        </div>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button className="gap-2">
              <Plus className="h-4 w-4" />
              Record Payment
            </Button>
          </DialogTrigger>
          <PaymentFormDialog onDone={() => setDialogOpen(false)} />
        </Dialog>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Payment History</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex justify-center py-10">
              <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
            </div>
          ) : !payments || payments.length === 0 ? (
            <p className="py-10 text-center text-sm text-muted-foreground">
              No payments recorded yet.
            </p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Client</TableHead>
                  <TableHead>Period</TableHead>
                  <TableHead className="text-right">Amount</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Paid on</TableHead>
                  <TableHead className="w-28" />
                </TableRow>
              </TableHeader>
              <TableBody>
                {payments.map((payment) => (
                  <PaymentRow key={payment.id} payment={payment} />
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function PaymentRow({
  payment,
}: {
  payment: NonNullable<ReturnType<typeof usePayments>["data"]>[number];
}) {
  const updateStatus = useUpdatePaymentStatus();
  const deletePayment = useDeletePayment();
  const isCleared = payment.status === "cleared";

  const toggleStatus = async () => {
    try {
      await updateStatus.mutateAsync({ id: payment.id, status: isCleared ? "pending" : "cleared" });
    } catch (err) {
      toast.error("Failed to update payment", { description: (err as Error).message });
    }
  };

  const handleDelete = async () => {
    if (!confirm("Delete this payment record?")) return;
    try {
      await deletePayment.mutateAsync(payment.id);
    } catch (err) {
      toast.error("Failed to delete payment", { description: (err as Error).message });
    }
  };

  return (
    <TableRow>
      <TableCell className="font-medium text-foreground">
        {payment.client?.client_name ?? "—"}
        <span className="block text-xs text-muted-foreground">{payment.client?.business_name}</span>
      </TableCell>
      <TableCell>
        {new Date(payment.period_month).toLocaleDateString("en-US", {
          month: "long",
          year: "numeric",
        })}
      </TableCell>
      <TableCell className="text-right">Rs. {Number(payment.amount).toLocaleString()}</TableCell>
      <TableCell>
        <Badge
          variant={isCleared ? "default" : "secondary"}
          className={isCleared ? "bg-emerald-600 hover:bg-emerald-600/90" : ""}
        >
          {isCleared ? "Cleared" : "Pending"}
        </Badge>
      </TableCell>
      <TableCell>{payment.paid_date ?? "—"}</TableCell>
      <TableCell>
        <div className="flex justify-end gap-1">
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8"
            title={isCleared ? "Mark as pending" : "Mark as cleared"}
            onClick={toggleStatus}
            disabled={updateStatus.isPending}
          >
            {isCleared ? (
              <Clock className="h-3.5 w-3.5" />
            ) : (
              <CheckCircle2 className="h-3.5 w-3.5 text-emerald-600" />
            )}
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8 text-destructive"
            onClick={handleDelete}
            disabled={deletePayment.isPending}
          >
            <Trash2 className="h-3.5 w-3.5" />
          </Button>
        </div>
      </TableCell>
    </TableRow>
  );
}

function PaymentFormDialog({ onDone }: { onDone: () => void }) {
  const { data: clients } = useClients();
  const createPayment = useCreatePayment();
  const [selectedClientId, setSelectedClientId] = useState<string>("");
  const [submitting, setSubmitting] = useState(false);

  const activeClients = useMemo(
    () => (clients ?? []).filter((c) => c.status === "active"),
    [clients],
  );
  const selectedClient = activeClients.find((c) => c.id === selectedClientId);

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = e.currentTarget;
    const data = new FormData(form);
    const monthValue = String(data.get("period_month")); // YYYY-MM
    const status = String(data.get("status")) as "pending" | "cleared";

    setSubmitting(true);
    try {
      await createPayment.mutateAsync({
        client_id: String(data.get("client_id")),
        amount: Number(data.get("amount")),
        period_month: `${monthValue}-01`,
        status,
        paid_date: status === "cleared" ? new Date().toISOString().slice(0, 10) : null,
      });
      toast.success("Payment recorded");
      onDone();
    } catch (err) {
      toast.error("Failed to record payment", { description: (err as Error).message });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <DialogContent>
      <DialogHeader>
        <DialogTitle>Record Payment</DialogTitle>
      </DialogHeader>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="space-y-1.5">
          <Label htmlFor="client_id">Client</Label>
          <select
            id="client_id"
            name="client_id"
            required
            value={selectedClientId}
            onChange={(e) => setSelectedClientId(e.target.value)}
            className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm shadow-sm"
          >
            <option value="" disabled>
              Select a client
            </option>
            {activeClients.map((client) => (
              <option key={client.id} value={client.id}>
                {client.client_name} — {client.business_name}
              </option>
            ))}
          </select>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-1.5">
            <Label htmlFor="period_month">Billing month</Label>
            <Input
              id="period_month"
              name="period_month"
              type="month"
              defaultValue={new Date().toISOString().slice(0, 7)}
              required
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="amount">Amount (Rs.)</Label>
            <Input
              id="amount"
              name="amount"
              type="number"
              min="0"
              step="1"
              key={selectedClient?.id}
              defaultValue={selectedClient?.monthly_retainer ?? ""}
              required
            />
          </div>
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="status">Status</Label>
          <select
            id="status"
            name="status"
            defaultValue="pending"
            className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm shadow-sm"
          >
            <option value="pending">Pending</option>
            <option value="cleared">Cleared</option>
          </select>
        </div>
        <Button type="submit" className="w-full" disabled={submitting}>
          {submitting && <Loader2 className="h-4 w-4 animate-spin" />}
          Save payment
        </Button>
      </form>
    </DialogContent>
  );
}
