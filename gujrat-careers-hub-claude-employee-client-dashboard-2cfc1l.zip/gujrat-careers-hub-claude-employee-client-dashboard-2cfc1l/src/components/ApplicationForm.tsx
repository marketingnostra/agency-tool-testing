import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";
import { Sparkles } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

type ApplyType = "Internship" | "Job";

export function ApplicationForm() {
  const [applyType, setApplyType] = useState<ApplyType | "">("");
  const [skill, setSkill] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = e.currentTarget;
    const data = new FormData(form);

    if (!data.get("fullName") || !data.get("email") || !data.get("whatsapp") || !applyType) {
      toast.error("Please fill all required fields.");
      return;
    }
    if (!skill) {
      toast.error("Please select your skill.");
      return;
    }

    setLoading(true);
    const payload = {
      full_name: String(data.get("fullName")),
      email: String(data.get("email")),
      whatsapp: String(data.get("whatsapp")),
      education: String(data.get("education")),
      apply_type: applyType,
      skill,
      why_intern: applyType === "Internship" ? String(data.get("whyIntern") ?? "") : null,
      experience_years: applyType === "Job" ? Number(data.get("experience")) : null,
      salary_expectation: applyType === "Job" ? Number(data.get("salary")) : null,
      why_hire: applyType === "Job" ? String(data.get("whyHire") ?? "") : null,
    };

    const { error } = await supabase.from("applications").insert(payload);
    setLoading(false);

    if (error) {
      console.error(error);
      toast.error("Submission failed. Please try again.");
      return;
    }

    toast.success("Application submitted! We'll be in touch soon.");
    form.reset();
    setApplyType("");
    setSkill("");
  };

  return (
    <form
      onSubmit={handleSubmit}
      className="relative rounded-2xl bg-card p-6 sm:p-8 shadow-elegant border border-border/60 backdrop-blur"
    >
      <div className="mb-6 flex items-center gap-2">
        <span className="inline-flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-accent text-primary-foreground">
          <Sparkles className="h-4 w-4" />
        </span>
        <div>
          <h3 className="text-lg font-semibold">Apply Now</h3>
          <p className="text-xs text-muted-foreground">It takes less than a minute</p>
        </div>
      </div>

      <div className="space-y-4">
        <div className="grid gap-2">
          <Label htmlFor="fullName">Full Name *</Label>
          <Input id="fullName" name="fullName" required placeholder="Your full name" />
        </div>

        <div className="grid sm:grid-cols-2 gap-4">
          <div className="grid gap-2">
            <Label htmlFor="email">Email *</Label>
            <Input id="email" name="email" type="email" required placeholder="you@email.com" />
          </div>
          <div className="grid gap-2">
            <Label htmlFor="whatsapp">WhatsApp Number *</Label>
            <Input id="whatsapp" name="whatsapp" required placeholder="+92 3xx xxxxxxx" />
          </div>
        </div>

        <div className="grid gap-2">
          <Label htmlFor="education">Education *</Label>
          <Input id="education" name="education" required placeholder="e.g. BS Computer Science" />
        </div>

        <div className="grid gap-2">
          <Label>Applying As *</Label>
          <Select value={applyType} onValueChange={(v) => { setApplyType(v as ApplyType); setSkill(""); }}>
            <SelectTrigger>
              <SelectValue placeholder="Choose Internship or Job" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Internship">Internship</SelectItem>
              <SelectItem value="Job">Job</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {applyType && (
          <div className="grid gap-2 animate-fade-up">
            <Label>{applyType === "Internship" ? "Preferred Skill *" : "Skill *"}</Label>
            <Select value={skill} onValueChange={setSkill}>
              <SelectTrigger>
                <SelectValue placeholder="Select a skill" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Social Media Management">Social Media Management</SelectItem>
                <SelectItem value="Graphic Design">Graphic Design</SelectItem>
                <SelectItem value="Video Editing">Video Editing</SelectItem>
              </SelectContent>
            </Select>
          </div>
        )}

        {applyType === "Internship" && (
          <div className="grid gap-2 animate-fade-up">
            <Label htmlFor="why-intern">Why do you want to do this internship? *</Label>
            <Textarea id="why-intern" name="whyIntern" required rows={4} placeholder="Tell us what excites you..." />
          </div>
        )}

        {applyType === "Job" && (
          <div className="space-y-4 animate-fade-up">
            <div className="grid sm:grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="experience">Years of Experience *</Label>
                <Input id="experience" name="experience" type="number" min={0} required placeholder="e.g. 3" />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="salary">Salary Expectation (PKR) *</Label>
                <Input id="salary" name="salary" type="number" min={0} required placeholder="25000" />
              </div>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="why-hire">Why should we hire you? *</Label>
              <Textarea id="why-hire" name="whyHire" required rows={4} placeholder="Share your strengths and proven results..." />
            </div>
          </div>
        )}

        <Button type="submit" variant="hero" size="lg" className="w-full" disabled={loading}>
          {loading ? "Submitting..." : "Apply Now"}
        </Button>
        <p className="text-[11px] text-muted-foreground text-center">
          By applying you agree to be contacted regarding this opportunity.
        </p>
      </div>
    </form>
  );
}
