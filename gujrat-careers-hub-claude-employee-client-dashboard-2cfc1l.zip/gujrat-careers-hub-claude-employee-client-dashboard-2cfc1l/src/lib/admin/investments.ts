import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { Tables, TablesInsert } from "@/integrations/supabase/types";

export type OwnerInvestment = Tables<"owner_investments">;
export type OwnerInvestmentInsert = TablesInsert<"owner_investments">;

const INVESTMENTS_KEY = ["admin", "investments"] as const;

export function useInvestments() {
  return useQuery({
    queryKey: INVESTMENTS_KEY,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("owner_investments")
        .select("*")
        .order("invested_date", { ascending: false });
      if (error) throw error;
      return data as OwnerInvestment[];
    },
  });
}

export function useCreateInvestment() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (input: OwnerInvestmentInsert) => {
      const { data, error } = await supabase
        .from("owner_investments")
        .insert(input)
        .select()
        .single();
      if (error) throw error;
      return data as OwnerInvestment;
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: INVESTMENTS_KEY }),
  });
}

export function useDeleteInvestment() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("owner_investments").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: INVESTMENTS_KEY }),
  });
}
