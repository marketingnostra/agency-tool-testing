import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Loader2, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { AdminGuard } from "@/components/admin/AdminGuard";
import { AdminShell } from "@/components/admin/AdminShell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useCreateInvestment, useDeleteInvestment, useInvestments } from "@/lib/admin/investments";

export const Route = createFileRoute("/admin/investments")({
  component: () => (
    <AdminGuard>
      <AdminShell>
        <InvestmentsPage />
      </AdminShell>
    </AdminGuard>
  ),
});

function InvestmentsPage() {
  const { data: investments, isLoading } = useInvestments();
  const [dialogOpen, setDialogOpen] = useState(false);
  const deleteInvestment = useDeleteInvestment();

  const totalInvested = (investments ?? []).reduce((sum, i) => sum + Number(i.amount), 0);

  const handleDelete = async (id: string) => {
    if (!confirm("Delete this investment record?")) return;
    try {
      await deleteInvestment.mutateAsync(id);
    } catch (err) {
      toast.error("Failed to delete investment", { description: (err as Error).message });
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-foreground">Owner Investments</h1>
          <p className="text-sm text-muted-foreground">
            Total injected:{" "}
            <span className="font-semibold text-emerald-600">
              Rs. {totalInvested.toLocaleString()}
            </span>
          </p>
        </div>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button className="gap-2">
              <Plus className="h-4 w-4" />
              Add Investment
            </Button>
          </DialogTrigger>
          <InvestmentFormDialog onDone={() => setDialogOpen(false)} />
        </Dialog>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">All Investments</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex justify-center py-10">
              <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
            </div>
          ) : !investments || investments.length === 0 ? (
            <p className="py-10 text-center text-sm text-muted-foreground">
              No investments recorded yet.
            </p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Owner</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead className="text-right">Amount</TableHead>
                  <TableHead className="w-16" />
                </TableRow>
              </TableHeader>
              <TableBody>
                {investments.map((investment) => (
                  <TableRow key={investment.id}>
                    <TableCell className="font-medium text-foreground">
                      {investment.owner_name}
                      {investment.notes && (
                        <span className="block text-xs text-muted-foreground">
                          {investment.notes}
                        </span>
                      )}
                    </TableCell>
                    <TableCell>{investment.invested_date}</TableCell>
                    <TableCell className="text-right text-emerald-600">
                      +Rs. {Number(investment.amount).toLocaleString()}
                    </TableCell>
                    <TableCell>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 text-destructive"
                        onClick={() => handleDelete(investment.id)}
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function InvestmentFormDialog({ onDone }: { onDone: () => void }) {
  const createInvestment = useCreateInvestment();
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = e.currentTarget;
    const data = new FormData(form);

    setSubmitting(true);
    try {
      await createInvestment.mutateAsync({
        owner_name: String(data.get("owner_name")),
        amount: Number(data.get("amount")),
        invested_date: String(data.get("invested_date")),
        notes: String(data.get("notes") || "") || null,
      });
      toast.success("Investment recorded");
      onDone();
    } catch (err) {
      toast.error("Failed to record investment", { description: (err as Error).message });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <DialogContent>
      <DialogHeader>
        <DialogTitle>Add Owner Investment</DialogTitle>
      </DialogHeader>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="space-y-1.5">
          <Label htmlFor="owner_name">Owner name</Label>
          <Input id="owner_name" name="owner_name" required />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-1.5">
            <Label htmlFor="amount">Amount (Rs.)</Label>
            <Input id="amount" name="amount" type="number" min="0" step="1" required />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="invested_date">Date</Label>
            <Input
              id="invested_date"
              name="invested_date"
              type="date"
              defaultValue={new Date().toISOString().slice(0, 10)}
              required
            />
          </div>
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="notes">Notes (optional)</Label>
          <Textarea id="notes" name="notes" rows={2} />
        </div>
        <Button type="submit" className="w-full" disabled={submitting}>
          {submitting && <Loader2 className="h-4 w-4 animate-spin" />}
          Add investment
        </Button>
      </form>
    </DialogContent>
  );
}
