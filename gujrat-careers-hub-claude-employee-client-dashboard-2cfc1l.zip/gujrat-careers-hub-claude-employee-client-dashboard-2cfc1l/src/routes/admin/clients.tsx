import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Loader2, Pencil, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { AdminGuard } from "@/components/admin/AdminGuard";
import { AdminShell } from "@/components/admin/AdminShell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  CLIENT_CATEGORIES,
  CLIENT_PLATFORMS,
  type Client,
  useClients,
  useCreateClient,
  useDeleteClient,
  useUpdateClient,
} from "@/lib/admin/clients";

export const Route = createFileRoute("/admin/clients")({
  component: () => (
    <AdminGuard>
      <AdminShell>
        <ClientsPage />
      </AdminShell>
    </AdminGuard>
  ),
});

function ClientsPage() {
  const { data: clients, isLoading } = useClients();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<Client | null>(null);

  const openCreate = () => {
    setEditing(null);
    setDialogOpen(true);
  };

  const openEdit = (client: Client) => {
    setEditing(client);
    setDialogOpen(true);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-foreground">Clients</h1>
          <p className="text-sm text-muted-foreground">Manage client accounts and retainers.</p>
        </div>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={openCreate} className="gap-2">
              <Plus className="h-4 w-4" />
              Add Client
            </Button>
          </DialogTrigger>
          <ClientFormDialog
            key={editing?.id ?? "new"}
            client={editing}
            onDone={() => setDialogOpen(false)}
          />
        </Dialog>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">All Clients</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex justify-center py-10">
              <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
            </div>
          ) : !clients || clients.length === 0 ? (
            <p className="py-10 text-center text-sm text-muted-foreground">No clients yet.</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Client</TableHead>
                  <TableHead>Business</TableHead>
                  <TableHead>Category</TableHead>
                  <TableHead>Platforms</TableHead>
                  <TableHead className="text-right">Retainer</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="w-20" />
                </TableRow>
              </TableHeader>
              <TableBody>
                {clients.map((client) => (
                  <ClientRow key={client.id} client={client} onEdit={() => openEdit(client)} />
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function ClientRow({ client, onEdit }: { client: Client; onEdit: () => void }) {
  const deleteClient = useDeleteClient();

  const handleDelete = async () => {
    if (!confirm(`Remove ${client.client_name}? This also removes their payment history.`)) return;
    try {
      await deleteClient.mutateAsync(client.id);
      toast.success("Client removed");
    } catch (err) {
      toast.error("Failed to remove client", { description: (err as Error).message });
    }
  };

  return (
    <TableRow>
      <TableCell className="font-medium text-foreground">{client.client_name}</TableCell>
      <TableCell>{client.business_name}</TableCell>
      <TableCell>{client.category}</TableCell>
      <TableCell>
        <div className="flex flex-wrap gap-1">
          {client.platforms.map((platform) => (
            <Badge key={platform} variant="secondary" className="text-[10px]">
              {platform}
            </Badge>
          ))}
        </div>
      </TableCell>
      <TableCell className="text-right">
        Rs. {Number(client.monthly_retainer).toLocaleString()}
      </TableCell>
      <TableCell>
        <Badge variant={client.status === "active" ? "default" : "secondary"}>
          {client.status}
        </Badge>
      </TableCell>
      <TableCell>
        <div className="flex justify-end gap-1">
          <Button variant="ghost" size="icon" className="h-8 w-8" onClick={onEdit}>
            <Pencil className="h-3.5 w-3.5" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8 text-destructive"
            onClick={handleDelete}
            disabled={deleteClient.isPending}
          >
            <Trash2 className="h-3.5 w-3.5" />
          </Button>
        </div>
      </TableCell>
    </TableRow>
  );
}

function ClientFormDialog({ client, onDone }: { client: Client | null; onDone: () => void }) {
  const createClient = useCreateClient();
  const updateClient = useUpdateClient();
  const [platforms, setPlatforms] = useState<string[]>(client?.platforms ?? []);
  const [submitting, setSubmitting] = useState(false);
  const isEditing = !!client;

  const togglePlatform = (platform: string, checked: boolean) => {
    setPlatforms((prev) => (checked ? [...prev, platform] : prev.filter((p) => p !== platform)));
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = e.currentTarget;
    const data = new FormData(form);

    setSubmitting(true);
    try {
      const payload = {
        client_name: String(data.get("client_name")),
        business_name: String(data.get("business_name")),
        category: String(data.get("category")),
        platforms,
        monthly_retainer: Number(data.get("monthly_retainer")),
        status: String(data.get("status")) as "active" | "inactive",
      };

      if (isEditing) {
        await updateClient.mutateAsync({ id: client.id, ...payload });
        toast.success("Client updated");
      } else {
        await createClient.mutateAsync(payload);
        toast.success("Client added");
      }
      onDone();
    } catch (err) {
      toast.error("Failed to save client", { description: (err as Error).message });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <DialogContent>
      <DialogHeader>
        <DialogTitle>{isEditing ? "Edit Client" : "Add Client"}</DialogTitle>
      </DialogHeader>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-1.5">
            <Label htmlFor="client_name">Client name</Label>
            <Input
              id="client_name"
              name="client_name"
              defaultValue={client?.client_name}
              required
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="business_name">Business name</Label>
            <Input
              id="business_name"
              name="business_name"
              defaultValue={client?.business_name}
              required
            />
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-1.5">
            <Label htmlFor="category">Category</Label>
            <select
              id="category"
              name="category"
              defaultValue={client?.category ?? CLIENT_CATEGORIES[0]}
              className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm shadow-sm"
            >
              {CLIENT_CATEGORIES.map((category) => (
                <option key={category} value={category}>
                  {category}
                </option>
              ))}
            </select>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="monthly_retainer">Monthly retainer (Rs.)</Label>
            <Input
              id="monthly_retainer"
              name="monthly_retainer"
              type="number"
              min="0"
              step="1"
              defaultValue={client?.monthly_retainer}
              required
            />
          </div>
        </div>
        <div className="space-y-1.5">
          <Label>Platforms included</Label>
          <div className="grid grid-cols-2 gap-2 rounded-md border border-input p-3">
            {CLIENT_PLATFORMS.map((platform) => (
              <label key={platform} className="flex items-center gap-2 text-sm">
                <Checkbox
                  checked={platforms.includes(platform)}
                  onCheckedChange={(checked) => togglePlatform(platform, !!checked)}
                />
                {platform}
              </label>
            ))}
          </div>
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="status">Status</Label>
          <select
            id="status"
            name="status"
            defaultValue={client?.status ?? "active"}
            className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm shadow-sm"
          >
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
          </select>
        </div>
        <Button type="submit" className="w-full" disabled={submitting}>
          {submitting && <Loader2 className="h-4 w-4 animate-spin" />}
          {isEditing ? "Save changes" : "Add client"}
        </Button>
      </form>
    </DialogContent>
  );
}
